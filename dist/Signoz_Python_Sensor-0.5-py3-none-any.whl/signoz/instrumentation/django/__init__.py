
try:
    import signoz.instrumentation.django.middleware
    
except ImportError:
    pass