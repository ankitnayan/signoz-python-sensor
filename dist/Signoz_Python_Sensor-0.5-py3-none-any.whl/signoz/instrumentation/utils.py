
def split_endpoint(endpoint):
    return endpoint.split("/")[1]